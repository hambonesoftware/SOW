"""Utility helpers for the SimpleSpecs backend."""

__all__: list[str] = []
