"""Submodule re-export for compatibility with Starlette imports."""

from __future__ import annotations

from python_multipart.multipart import *  # noqa: F401,F403
